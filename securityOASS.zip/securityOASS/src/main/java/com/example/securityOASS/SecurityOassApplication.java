package com.example.securityOASS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityOassApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityOassApplication.class, args);
	}

}
