package com.example.securityOAS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityOasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityOasApplication.class, args);
	}

}
